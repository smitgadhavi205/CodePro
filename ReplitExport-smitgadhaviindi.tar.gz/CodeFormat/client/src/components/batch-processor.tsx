import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { FileText, Download, CheckCircle, AlertCircle, Clock } from "lucide-react";

interface ParsedPractical {
  practicalNo?: string;
  title: string;
  aim: string;
  code: string;
  language: string;
  output?: string;
}

interface BatchProcessorProps {
  practicals: ParsedPractical[];
  onClose: () => void;
}

interface ProcessingStatus {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  practical: ParsedPractical;
  documentUrl?: string;
  error?: string;
}

export default function BatchProcessor({ practicals, onClose }: BatchProcessorProps) {
  const { toast } = useToast();
  const [processingItems, setProcessingItems] = useState<ProcessingStatus[]>(
    practicals.map((practical, index) => ({
      id: `practical-${index}`,
      status: 'pending',
      practical
    }))
  );
  const [selectedFormat, setSelectedFormat] = useState<'pdf' | 'docx'>('pdf');

  const batchProcessMutation = useMutation({
    mutationFn: async () => {
      const results: ProcessingStatus[] = [];
      
      for (let i = 0; i < processingItems.length; i++) {
        const item = processingItems[i];
        
        // Update status to processing
        setProcessingItems(prev => 
          prev.map(p => p.id === item.id ? { ...p, status: 'processing' } : p)
        );

        try {
          // Create practical
          const practicalResponse = await apiRequest("POST", "/api/practicals", {
            ...item.practical,
            format: selectedFormat,
            userId: "demo-user"
          });
          const practicalData = await practicalResponse.json();

          // Generate document
          const documentResponse = await fetch("/api/generate-document", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              practicalId: practicalData.practical.id,
              format: selectedFormat
            })
          });

          if (!documentResponse.ok) {
            throw new Error("Document generation failed");
          }

          // Create download link
          const blob = await documentResponse.blob();
          const url = window.URL.createObjectURL(blob);
          
          const updatedItem: ProcessingStatus = {
            ...item,
            status: 'completed',
            documentUrl: url
          };
          
          results.push(updatedItem);
          
          // Update individual item status
          setProcessingItems(prev => 
            prev.map(p => p.id === item.id ? updatedItem : p)
          );

        } catch (error) {
          const failedItem: ProcessingStatus = {
            ...item,
            status: 'failed',
            error: (error as Error).message
          };
          
          results.push(failedItem);
          
          setProcessingItems(prev => 
            prev.map(p => p.id === item.id ? failedItem : p)
          );
        }

        // Small delay between processing items
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      return results;
    },
    onSuccess: (results) => {
      const completed = results.filter(r => r.status === 'completed').length;
      const failed = results.filter(r => r.status === 'failed').length;
      
      toast({
        title: "Batch processing completed",
        description: `${completed} practicals processed successfully, ${failed} failed`,
      });
    },
    onError: (error) => {
      toast({
        title: "Batch processing failed",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  });

  const downloadAll = () => {
    const completedItems = processingItems.filter(item => item.status === 'completed' && item.documentUrl);
    
    completedItems.forEach((item, index) => {
      setTimeout(() => {
        if (item.documentUrl) {
          const a = document.createElement('a');
          a.href = item.documentUrl;
          a.download = `${item.practical.title || `practical-${index + 1}`}.${selectedFormat === 'pdf' ? 'html' : 'json'}`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
      }, index * 100); // Stagger downloads
    });
  };

  const completedCount = processingItems.filter(item => item.status === 'completed').length;
  const failedCount = processingItems.filter(item => item.status === 'failed').length;
  const progress = (completedCount + failedCount) / processingItems.length * 100;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <FileText className="mr-2 text-primary" size={20} />
            Batch Processing ({processingItems.length} practicals)
          </span>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Format Selection */}
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium">Output Format:</span>
          <div className="flex space-x-2">
            <Button
              variant={selectedFormat === 'pdf' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedFormat('pdf')}
            >
              PDF
            </Button>
            <Button
              variant={selectedFormat === 'docx' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedFormat('docx')}
            >
              Word
            </Button>
          </div>
        </div>

        {/* Progress Overview */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Processing Progress</span>
            <span className="text-sm text-slate-500">
              {completedCount + failedCount} / {processingItems.length}
            </span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-3">
          <Button 
            onClick={() => batchProcessMutation.mutate()}
            disabled={batchProcessMutation.isPending}
            className="flex-1"
          >
            {batchProcessMutation.isPending ? "Processing..." : "Start Processing"}
          </Button>
          
          {completedCount > 0 && (
            <Button 
              onClick={downloadAll}
              variant="outline"
              className="flex items-center"
            >
              <Download className="mr-2" size={16} />
              Download All ({completedCount})
            </Button>
          )}
        </div>

        {/* Processing Items List */}
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {processingItems.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex-1">
                <h4 className="font-medium text-sm">{item.practical.title}</h4>
                <p className="text-xs text-slate-500 truncate">
                  {item.practical.aim}
                </p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="outline" className="text-xs">
                    {item.practical.language}
                  </Badge>
                  {item.practical.practicalNo && (
                    <Badge variant="outline" className="text-xs">
                      #{item.practical.practicalNo}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {item.status === 'pending' && (
                  <Clock className="text-slate-400" size={16} />
                )}
                {item.status === 'processing' && (
                  <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
                )}
                {item.status === 'completed' && (
                  <>
                    <CheckCircle className="text-green-500" size={16} />
                    {item.documentUrl && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          const a = document.createElement('a');
                          a.href = item.documentUrl!;
                          a.download = `${item.practical.title}.${selectedFormat === 'pdf' ? 'html' : 'json'}`;
                          a.click();
                        }}
                      >
                        <Download size={14} />
                      </Button>
                    )}
                  </>
                )}
                {item.status === 'failed' && (
                  <div className="flex items-center space-x-1">
                    <AlertCircle className="text-red-500" size={16} />
                    <span className="text-xs text-red-500">{item.error}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}