import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Copy, ClipboardType, Terminal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CodeEditorProps {
  code: string;
  onChange: (code: string) => void;
  language: string;
  onValidate?: () => void;
  isValidating?: boolean;
}

export default function CodeEditor({ 
  code, 
  onChange, 
  language, 
  onValidate, 
  isValidating = false 
}: CodeEditorProps) {
  const { toast } = useToast();
  const [stats, setStats] = useState({
    lines: code.split('\n').length,
    chars: code.length
  });

  const handleCodeChange = (newCode: string) => {
    onChange(newCode);
    setStats({
      lines: newCode.split('\n').length,
      chars: newCode.length
    });
  };

  const handlePasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      handleCodeChange(text);
      toast({
        title: "Code pasted",
        description: "Code has been pasted from clipboard",
      });
    } catch (error) {
      toast({
        title: "ClipboardType failed",
        description: "Could not access clipboard",
        variant: "destructive",
      });
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(code);
      toast({
        title: "Code copied",
        description: "Code has been copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
      <div className="flex items-center justify-between mb-3">
        <label className="text-sm font-medium text-slate-700">
          <Terminal className="inline mr-2 text-primary" size={16} />
          Your Code
        </label>
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handlePasteFromClipboard}
            className="text-primary hover:text-blue-700"
          >
            <ClipboardType className="mr-1" size={14} />
            ClipboardType
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopyCode}
            className="text-primary hover:text-blue-700"
          >
            <Copy className="mr-1" size={14} />
            Copy
          </Button>
        </div>
      </div>
      
      <div className="relative">
        <Textarea
          value={code}
          onChange={(e) => handleCodeChange(e.target.value)}
          className="code-editor min-h-[300px] font-mono text-sm resize-none"
          placeholder="ClipboardType your code here..."
        />
      </div>
      
      <div className="flex items-center justify-between mt-3">
        <div className="flex items-center space-x-4">
          <span className="text-xs text-slate-500">Lines: {stats.lines}</span>
          <span className="text-xs text-slate-500">Characters: {stats.chars}</span>
          <span className="text-xs text-slate-500">Language: {language}</span>
        </div>
        {onValidate && (
          <Button 
            onClick={onValidate}
            disabled={isValidating || !code.trim()}
            size="sm"
          >
            <Terminal className="mr-2" size={14} />
            {isValidating ? "Validating..." : "Validate Code"}
          </Button>
        )}
      </div>
    </div>
  );
}
