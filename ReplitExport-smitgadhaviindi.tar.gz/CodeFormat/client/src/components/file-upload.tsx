import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, File, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ParsedPractical {
  practicalNo?: string;
  title: string;
  aim: string;
  code: string;
  language: string;
  output?: string;
}

interface FileUploadProps {
  onFileExtracted?: (data: any) => void;
  onBatchExtracted?: (practicals: ParsedPractical[]) => void;
}

export default function FileUpload({ onFileExtracted, onBatchExtracted }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelection(files[0]);
    }
  };

  const handleFileSelection = async (file: File) => {
    const allowedTypes = [
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain'
    ];

    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload DOC, DOCX, or TXT files only",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB
      toast({
        title: "File too large",
        description: "Please upload files smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    setUploadedFile(file);
    await uploadFile(file);
  };

  const uploadFile = async (file: File) => {
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload-practical', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      
      if (result.practicals && result.practicals.length > 1) {
        // Multiple practicals found - use batch processing
        toast({
          title: "Multiple practicals found",
          description: `Found ${result.count} practicals in your document`,
        });

        if (onBatchExtracted) {
          onBatchExtracted(result.practicals);
        }
      } else if (result.practicals && result.practicals.length === 1) {
        // Single practical found - use single mode
        toast({
          title: "File uploaded successfully",
          description: "Extracted practical details from your file",
        });

        if (onFileExtracted) {
          onFileExtracted(result.practicals[0]);
        }
      } else {
        toast({
          title: "No practicals found",
          description: "Could not extract practical details from the file",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Could not process your file",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelection(files[0]);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Upload className="mr-2 text-primary" size={20} />
          Or Upload Existing Practical
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!uploadedFile ? (
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              isDragging 
                ? 'border-primary bg-blue-50' 
                : 'border-slate-300 hover:border-primary'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="mx-auto text-3xl text-slate-400 mb-2" size={48} />
            <p className="text-sm text-slate-600 mb-2">
              Drag and drop files here or click to browse
            </p>
            <p className="text-xs text-slate-500">
              Supports .doc, .docx, .txt files (max 10MB)
            </p>
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept=".doc,.docx,.txt"
              onChange={handleFileInputChange}
            />
          </div>
        ) : (
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <File className="text-slate-600" size={20} />
              <div>
                <p className="text-sm font-medium text-slate-900">{uploadedFile.name}</p>
                <p className="text-xs text-slate-500">
                  {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {isUploading && (
                <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={removeFile}
                className="text-slate-600 hover:text-red-600"
              >
                <X size={16} />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
