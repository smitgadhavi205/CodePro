import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { FileText, Download } from "lucide-react";

interface FormatSelectorProps {
  format: string;
  onChange: (format: string) => void;
}

export default function FormatSelector({ format, onChange }: FormatSelectorProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="mr-2 text-primary" size={20} />
          Output Format
        </CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup value={format} onValueChange={onChange} className="grid grid-cols-2 gap-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="pdf" id="pdf" />
            <Label 
              htmlFor="pdf" 
              className="flex items-center space-x-3 p-4 border border-slate-300 rounded-lg cursor-pointer hover:border-primary transition-colors flex-1"
            >
              <div className="text-red-500 text-xl">📄</div>
              <span className="text-sm font-medium text-slate-900">PDF</span>
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="docx" id="docx" />
            <Label 
              htmlFor="docx" 
              className="flex items-center space-x-3 p-4 border border-slate-300 rounded-lg cursor-pointer hover:border-primary transition-colors flex-1"
            >
              <div className="text-blue-600 text-xl">📘</div>
              <span className="text-sm font-medium text-slate-900">Word</span>
            </Label>
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  );
}
