import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Code, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Code className="text-white text-sm" size={16} />
            </div>
            <h1 className="text-xl font-bold text-slate-900">PracticalFormatAI</h1>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/#features" className="text-slate-600 hover:text-primary transition-colors">
              Features
            </Link>
            <Link href="/pricing" className="text-slate-600 hover:text-primary transition-colors">
              Pricing
            </Link>
            <Link href="/#contact" className="text-slate-600 hover:text-primary transition-colors">
              Contact
            </Link>
            <Link href="/dashboard">
              <Button>Get Started</Button>
            </Link>
          </nav>
          
          <button 
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="text-slate-600" /> : <Menu className="text-slate-600" />}
          </button>
        </div>
        
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-200">
            <div className="flex flex-col space-y-4">
              <Link href="/#features" className="text-slate-600 hover:text-primary transition-colors">
                Features
              </Link>
              <Link href="/pricing" className="text-slate-600 hover:text-primary transition-colors">
                Pricing
              </Link>
              <Link href="/#contact" className="text-slate-600 hover:text-primary transition-colors">
                Contact
              </Link>
              <Link href="/dashboard">
                <Button className="w-full">Get Started</Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
