import { CheckCircle, AlertTriangle, XCircle, Bot } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ValidationResult {
  isValid: boolean;
  score: number;
  issues: string[];
  suggestions: string[];
  hasOutput: boolean;
  generatedOutput?: string;
}

interface ValidationStatusProps {
  validation?: ValidationResult;
  isLoading: boolean;
}

export default function ValidationStatus({ validation, isLoading }: ValidationStatusProps) {
  // Add safety checks for validation data
  const safeValidation = validation ? {
    ...validation,
    issues: validation.issues || [],
    suggestions: validation.suggestions || [],
    generatedOutput: validation.generatedOutput || ''
  } : null;
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bot className="mr-2 text-primary" size={20} />
            AI Code Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
            <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
            <span className="text-sm font-medium text-blue-800">Analyzing your code...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!safeValidation) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bot className="mr-2 text-primary" size={20} />
            AI Code Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600">Click "Validate Code" to analyze your code with AI</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bot className="mr-2 text-primary" size={20} />
          AI Code Analysis
          <span className="ml-auto text-sm font-normal text-slate-600">
            Score: {safeValidation.score}/100
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Validation Results */}
        <div className="space-y-3">
          {safeValidation.isValid && (
            <div className="flex items-center space-x-3 p-3 validation-success rounded-lg">
              <CheckCircle className="text-green-600" size={16} />
              <span className="text-sm font-medium">Code validation passed</span>
            </div>
          )}
          
          {safeValidation.issues && safeValidation.issues.length === 0 && (
            <div className="flex items-center space-x-3 p-3 validation-success rounded-lg">
              <CheckCircle className="text-green-600" size={16} />
              <span className="text-sm font-medium">No issues found</span>
            </div>
          )}
          
          {safeValidation.issues && safeValidation.issues.map((issue, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 validation-warning rounded-lg">
              <AlertTriangle className="text-yellow-600" size={16} />
              <span className="text-sm font-medium">{issue}</span>
            </div>
          ))}
        </div>

        {/* AI Suggestions */}
        {safeValidation.suggestions && safeValidation.suggestions.length > 0 && (
          <div className="p-4 bg-blue-50 rounded-lg">
            <h4 className="text-sm font-medium text-blue-900 mb-2">💡 AI Suggestions</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              {safeValidation.suggestions.map((suggestion, index) => (
                <li key={index}>• {suggestion}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Generated Output */}
        {safeValidation.generatedOutput && (
          <div className="p-4 bg-green-50 rounded-lg">
            <h4 className="text-sm font-medium text-green-900 mb-2">🚀 Generated Output</h4>
            <pre className="text-sm text-green-800 whitespace-pre-wrap">{safeValidation.generatedOutput}</pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
