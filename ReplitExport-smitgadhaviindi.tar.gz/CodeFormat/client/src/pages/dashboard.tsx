import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import Footer from "@/components/footer";
import CodeEditor from "@/components/code-editor";
import ValidationStatus from "@/components/validation-status";
import FormatSelector from "@/components/format-selector";
import FileUpload from "@/components/file-upload";
import BatchProcessor from "@/components/batch-processor";
import { Target, Sparkles, Download } from "lucide-react";

interface PracticalData {
  title: string;
  aim: string;
  language: string;
  code: string;
  format: string;
}

interface ValidationResult {
  validation: {
    isValid: boolean;
    score: number;
    issues: string[];
    suggestions: string[];
    hasOutput: boolean;
    generatedOutput?: string;
  };
  output: string;
  executionTime: string;
  errors: string[];
}

export default function Dashboard() {
  const { toast } = useToast();
  const [practical, setPractical] = useState<PracticalData>({
    title: "",
    aim: "",
    language: "python",
    code: "",
    format: "pdf"
  });
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [batchPracticals, setBatchPracticals] = useState<any[] | null>(null);

  const validateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/validate-code", {
        code: practical.code,
        language: practical.language,
        aim: practical.aim
      });
      return response.json();
    },
    onSuccess: (data) => {
      setValidationResult(data);
      toast({
        title: "Code validated",
        description: `Validation score: ${data.validation.score}/100`,
      });
    },
    onError: (error) => {
      toast({
        title: "Validation failed",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      // First create the practical
      const practicalResponse = await apiRequest("POST", "/api/practicals", {
        ...practical,
        userId: "demo-user" // In production, this would come from auth
      });
      const practicalData = await practicalResponse.json();

      // Then generate the document
      const response = await fetch("/api/generate-document", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          practicalId: practicalData.practical.id,
          format: practical.format
        })
      });

      if (!response.ok) {
        throw new Error("Document generation failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${practical.title || 'practical'}.${practical.format === 'pdf' ? 'html' : 'json'}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Document generated",
        description: "Your practical has been downloaded successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation failed",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  });

  const handleFileExtracted = (extractedData: any) => {
    setPractical(prev => ({
      ...prev,
      title: extractedData.title || prev.title,
      aim: extractedData.aim || prev.aim,
      code: extractedData.code || prev.code,
      language: extractedData.language || prev.language
    }));
  };

  const handleBatchExtracted = (practicals: any[]) => {
    setBatchPracticals(practicals);
  };

  const canGenerate = practical.title && practical.aim && practical.code && validationResult?.validation.isValid;

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Smart Practical Formatter</h1>
          <p className="text-slate-600">Create professionally formatted CS practicals with AI assistance</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Panel - Input Section */}
          <div className="space-y-6">
            {/* Title Input */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="mr-2 text-primary" size={20} />
                  Practical Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Practical Title</Label>
                  <Input
                    id="title"
                    value={practical.title}
                    onChange={(e) => setPractical(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter practical title (e.g., Binary Search Implementation)"
                  />
                </div>
                
                <div>
                  <Label htmlFor="aim">Practical Aim/Objective</Label>
                  <Textarea
                    id="aim"
                    value={practical.aim}
                    onChange={(e) => setPractical(prev => ({ ...prev, aim: e.target.value }))}
                    placeholder="Enter the aim of your practical (e.g., Write a Python program to implement binary search algorithm)"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="language">Programming Language</Label>
                  <Select value={practical.language} onValueChange={(value) => setPractical(prev => ({ ...prev, language: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="python">Python</SelectItem>
                      <SelectItem value="java">Java</SelectItem>
                      <SelectItem value="cpp">C++</SelectItem>
                      <SelectItem value="c">C</SelectItem>
                      <SelectItem value="javascript">JavaScript</SelectItem>
                      <SelectItem value="html">HTML</SelectItem>
                      <SelectItem value="css">CSS</SelectItem>
                      <SelectItem value="php">PHP</SelectItem>
                      <SelectItem value="sql">SQL</SelectItem>
                      <SelectItem value="react">React JSX</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Code Editor */}
            <CodeEditor
              code={practical.code}
              onChange={(code) => setPractical(prev => ({ ...prev, code }))}
              language={practical.language}
              onValidate={() => validateMutation.mutate()}
              isValidating={validateMutation.isPending}
            />

            {/* File Upload */}
            <FileUpload 
              onFileExtracted={handleFileExtracted}
              onBatchExtracted={handleBatchExtracted}
            />
          </div>

          {/* Right Panel - AI Processing & Output */}
          <div className="space-y-6">
            {/* AI Validation Status */}
            <ValidationStatus 
              validation={validationResult?.validation}
              isLoading={validateMutation.isPending}
            />

            {/* Expected Output Preview */}
            {validationResult && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Sparkles className="mr-2 text-primary" size={20} />
                    Generated Output
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-sm">
                    <div className="text-slate-500 mb-2">$ {practical.language} {practical.title.toLowerCase().replace(/\s+/g, '_')}</div>
                    <div className="whitespace-pre-wrap">{validationResult.output}</div>
                    <div className="text-slate-500 mt-2">
                      Execution time: {validationResult.executionTime}
                    </div>
                  </div>
                  <div className="mt-3 text-xs text-slate-500">
                    ℹ️ AI-generated output based on your code execution
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Format Selection */}
            <FormatSelector
              format={practical.format}
              onChange={(format) => setPractical(prev => ({ ...prev, format }))}
            />

            {/* Generate Button */}
            <Button 
              className="w-full py-6 text-lg font-semibold"
              size="lg"
              onClick={() => generateMutation.mutate()}
              disabled={!canGenerate || generateMutation.isPending}
            >
              <Download className="mr-2" size={20} />
              {generateMutation.isPending ? "Generating..." : "Generate Formatted Practical"}
            </Button>

            {!canGenerate && (
              <p className="text-sm text-slate-500 text-center">
                Complete all fields and validate your code to generate the document
              </p>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-12 text-center">
          <div className="bg-blue-50 rounded-xl p-6 max-w-2xl mx-auto">
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Need More Features?</h3>
            <p className="text-slate-600 mb-4">
              Upgrade to Student or Pro plan for unlimited practicals, advanced AI features, and priority support.
            </p>
            <Link href="/pricing">
              <Button variant="outline">View Pricing Plans</Button>
            </Link>
          </div>
        </div>
      </div>

      <Footer />
      
      {/* Batch Processing Modal */}
      {batchPracticals && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <BatchProcessor 
            practicals={batchPracticals}
            onClose={() => setBatchPracticals(null)}
          />
        </div>
      )}
    </div>
  );
}
