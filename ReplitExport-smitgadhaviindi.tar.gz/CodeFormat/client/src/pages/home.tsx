import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { 
  Rocket, 
  Play, 
  Bot, 
  Zap, 
  FileOutput, 
  Code, 
  Upload,
  CheckCircle,
  Star
} from "lucide-react";

export default function Home() {
  const [currentStep, setCurrentStep] = useState(1);

  const features = [
    {
      icon: Bot,
      title: "AI Code Validation",
      description: "Automatically check your code for syntax errors, logic issues, and best practices with advanced AI analysis."
    },
    {
      icon: Zap,
      title: "Instant Formatting",
      description: "Transform your code into professionally formatted practicals in seconds, not hours."
    },
    {
      icon: Play,
      title: "Output Generation",
      description: "AI generates the expected output for your code, so you never submit incomplete practicals."
    },
    {
      icon: FileOutput,
      title: "Multiple Formats",
      description: "Export your practicals in PDF or Word format, perfectly formatted for submission."
    },
    {
      icon: Code,
      title: "Multi-Language Support",
      description: "Supports Python, Java, C++, C, JavaScript, HTML, CSS, PHP, SQL, React and more programming languages."
    },
    {
      icon: Upload,
      title: "Batch Processing",
      description: "Upload Word/text documents with multiple practicals and process them all at once for maximum efficiency."
    }
  ];

  const testimonials = [
    {
      name: "Raj Patel",
      role: "CSE Final Year, IIT Delhi",
      content: "This tool saved me hours every week! No more manual formatting, and the AI catches errors I would have missed. Perfect for our college practicals.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    },
    {
      name: "Priya Sharma", 
      role: "IT 3rd Year, NIT Kurukshetra",
      content: "The AI validation feature is incredible! It not only checks syntax but also suggests improvements. My grades improved significantly.",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    },
    {
      name: "Arjun Kumar",
      role: "CSE 2nd Year, VIT Vellore", 
      content: "Game changer for our practical submissions! The output generation feature ensures we never miss the results section. Highly recommended!",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      {/* Hero Section */}
      <section className="gradient-hero py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Format CS Practicals with 
              <span className="block text-white">AI Power</span>
            </h1>
            <p className="text-xl opacity-90 mb-8 max-w-3xl mx-auto">
              Save hours on formatting, validate your code with AI, and generate professional practical documents instantly. Perfect for CS students who want to focus on learning, not formatting.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/dashboard">
                <Button size="lg" className="bg-white text-primary hover:bg-slate-100">
                  <Rocket className="mr-2" size={20} />
                  Start Formatting Now
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
                <Play className="mr-2" size={20} />
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Step Progress Preview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Smart Practical Formatter</h2>
            <p className="text-slate-600 text-lg">Follow these simple steps to create perfectly formatted practicals</p>
          </div>

          <div className="flex justify-center mb-12">
            <div className="flex items-center space-x-4">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step === 1 ? 'bg-primary text-white' : 'bg-slate-300 text-slate-600'
                  }`}>
                    {step}
                  </div>
                  <span className={`ml-2 text-sm font-medium ${
                    step === 1 ? 'text-primary' : 'text-slate-500'
                  }`}>
                    {step === 1 ? 'Aim & Code' : step === 2 ? 'AI Validation' : 'Generate'}
                  </span>
                  {step < 3 && <div className="w-8 h-0.5 bg-slate-300 ml-4"></div>}
                </div>
              ))}
            </div>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="p-8">
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-4">Ready to Get Started?</h3>
                <p className="text-slate-600 mb-6">
                  Join thousands of CS students who are already formatting smarter with AI assistance
                </p>
                <Link href="/dashboard">
                  <Button size="lg">
                    Try It Now - It's Free!
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Why Choose PracticalFormatAI?</h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">Built specifically for CS students who want to save time and create professional practicals</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="text-primary text-xl" size={24} />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">What Students Say</h2>
            <p className="text-xl text-slate-600">Join thousands of CS students saving time daily</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="fill-current" size={16} />
                      ))}
                    </div>
                  </div>
                  <p className="text-slate-600 mb-4">"{testimonial.content}"</p>
                  <div className="flex items-center">
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name}
                      className="w-10 h-10 rounded-full mr-3"
                    />
                    <div>
                      <p className="font-medium text-slate-900">{testimonial.name}</p>
                      <p className="text-sm text-slate-500">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-hero text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Save Hours on Practicals?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of CS students who are already formatting smarter, not harder.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <Button size="lg" className="bg-white text-primary hover:bg-slate-100">
                Start Free Trial
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
              Schedule Demo
            </Button>
          </div>
          <p className="text-sm mt-4 opacity-75">No credit card required • 5 free practicals included</p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
