import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Check, X, Star } from "lucide-react";

export default function Pricing() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const plans = [
    {
      id: "free",
      name: "Free",
      price: "₹0",
      period: "/month",
      description: "Perfect for trying out the service",
      features: [
        "5 practicals per month",
        "Basic AI validation",
        "PDF export only",
      ],
      limitations: [
        "No Word export",
        "Basic support only",
      ],
      buttonText: "Get Started Free",
      buttonVariant: "outline" as const,
      popular: false,
    },
    {
      id: "student",
      name: "Student",
      price: "₹99",
      period: "/month",
      description: "Perfect for regular use",
      features: [
        "50 practicals per month",
        "Advanced AI validation",
        "PDF & Word export",
        "File upload support",
        "Priority support",
      ],
      limitations: [],
      buttonText: "Choose Student Plan",
      buttonVariant: "default" as const,
      popular: true,
    },
    {
      id: "pro",
      name: "Pro",
      price: "₹199",
      period: "/month",
      description: "For heavy users and groups",
      features: [
        "Unlimited practicals",
        "Premium AI features",
        "All export formats",
        "Batch processing",
        "Custom templates",
        "24/7 support",
      ],
      limitations: [],
      buttonText: "Choose Pro Plan",
      buttonVariant: "outline" as const,
      popular: false,
    },
  ];

  const handlePlanSelect = (planId: string) => {
    setSelectedPlan(planId);
    // Here you would redirect to payment flow
    console.log(`Selected plan: ${planId}`);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Student-Friendly Pricing</h1>
          <p className="text-xl text-slate-600">Affordable plans designed for college budgets</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <Card 
              key={plan.id} 
              className={`relative ${
                plan.popular 
                  ? 'border-primary shadow-lg scale-105 bg-primary text-white' 
                  : 'border-slate-200'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-green-500 text-white px-4 py-1">
                    <Star className="mr-1" size={12} />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center">
                <h3 className={`text-xl font-semibold mb-2 ${
                  plan.popular ? 'text-white' : 'text-slate-900'
                }`}>
                  {plan.name}
                </h3>
                <div className={`text-3xl font-bold mb-4 ${
                  plan.popular ? 'text-white' : 'text-slate-900'
                }`}>
                  {plan.price}
                  <span className={`text-sm ${
                    plan.popular ? 'opacity-80' : 'text-slate-500'
                  }`}>
                    {plan.period}
                  </span>
                </div>
                <p className={`${
                  plan.popular ? 'opacity-90 text-white' : 'text-slate-600'
                } mb-6`}>
                  {plan.description}
                </p>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className={`flex items-center ${
                      plan.popular ? 'text-white' : 'text-slate-600'
                    }`}>
                      <Check className={`mr-3 ${
                        plan.popular ? 'text-green-300' : 'text-green-500'
                      }`} size={16} />
                      {feature}
                    </li>
                  ))}
                  {plan.limitations.map((limitation, index) => (
                    <li key={index} className="flex items-center text-slate-500">
                      <X className="text-slate-400 mr-3" size={16} />
                      {limitation}
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full py-3 ${
                    plan.popular 
                      ? 'bg-white text-primary hover:bg-slate-100' 
                      : ''
                  }`}
                  variant={plan.popular ? "secondary" : plan.buttonVariant}
                  onClick={() => handlePlanSelect(plan.id)}
                >
                  {plan.buttonText}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-20 max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-slate-900 text-center mb-12">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-slate-900 mb-2">How does the free plan work?</h3>
                <p className="text-slate-600">
                  The free plan allows you to format up to 5 practicals per month with basic AI validation and PDF export. 
                  Perfect for trying out our service before upgrading.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-slate-900 mb-2">Can I upgrade or downgrade anytime?</h3>
                <p className="text-slate-600">
                  Yes! You can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-slate-900 mb-2">What programming languages are supported?</h3>
                <p className="text-slate-600">
                  We support Python, Java, C++, C, JavaScript, HTML, CSS, PHP, SQL, React and more. Our AI can analyze and validate code in most popular programming languages.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-slate-900 mb-2">Is there a student discount?</h3>
                <p className="text-slate-600">
                  Our pricing is already designed with students in mind! The Student plan at ₹99/month provides excellent value for regular users.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <div className="bg-gradient-to-r from-primary to-blue-600 rounded-xl p-8 text-white max-w-4xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Save Hours on Practicals?</h2>
            <p className="text-lg mb-6 opacity-90">
              Join thousands of CS students who are already formatting smarter, not harder.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/dashboard">
                <Button size="lg" className="bg-white text-primary hover:bg-slate-100">
                  Start Free Trial
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-primary">
                Contact Sales
              </Button>
            </div>
            <p className="text-sm mt-4 opacity-75">No credit card required • 5 free practicals included</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
