# PracticalFormatAI - Code Agent Documentation

## Overview

PracticalFormatAI is a web application designed to help CS students format their programming practicals with AI-powered code validation and professional document generation. The application transforms student code into properly formatted documents (PDF/Word) with automated validation, output generation, and professional styling.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 28, 2025)

✓ Added support for HTML, CSS, JavaScript, SQL, and React JSX languages
✓ Enhanced document parser to extract multiple practicals from single documents
✓ Implemented batch processing feature for handling multiple practicals simultaneously
✓ Improved file upload to support Word documents and text files with intelligent parsing
✓ Created batch processor component with progress tracking and bulk download
✓ Updated language detection to recognize web development languages
✓ Removed PDF support temporarily due to library initialization issues
✓ Replaced OpenAI API with custom local AI service to eliminate external costs
✓ Implemented intelligent code validation with language-specific patterns
✓ Built smart output generation system without external API dependencies

## System Architecture

The application follows a modern full-stack architecture with a clear separation between client and server components:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Authentication**: Session-based with express-session
- **File Uploads**: Multer middleware for handling file uploads
- **Payment Processing**: Stripe integration for subscription management

### Development Environment
- **Deployment**: Replit-optimized with development banners and cartographer
- **Hot Reload**: Vite HMR in development
- **Error Handling**: Runtime error overlay for development

## Key Components

### Database Schema
The application uses PostgreSQL with two main tables:
- **Users**: Stores user accounts with authentication, Stripe integration, and plan management
- **Practicals**: Stores code submissions with validation results and generated documents

### AI Integration
- **Local AI Service**: Custom intelligent code validation and output generation without external APIs
- **Language-Specific Patterns**: Advanced syntax checking for Python, Java, C++, C, JavaScript, HTML, CSS, PHP, SQL
- **Smart Code Analysis**: Provides scoring, error detection, and improvement suggestions
- **Intelligent Output Generation**: Context-aware output generation based on code patterns and language

### Document Generation
- **PDF Generation**: HTML-to-PDF conversion with professional styling
- **Word Documents**: DOCX format support for institutional requirements
- **Template System**: Standardized practical report format with student information

### Payment System
- **Stripe Integration**: Handles subscription management for different pricing tiers
- **Plan Management**: Free (5 practicals), Student (₹99/month, 50 practicals), Pro (₹199/month, unlimited)
- **Usage Tracking**: Monitors practical generation limits per plan

## Data Flow

1. **User Registration/Login**: Users create accounts and authenticate via session-based auth
2. **Code Submission**: Students input practical details (title, aim, code, language)
3. **AI Validation**: Code is sent to OpenAI for syntax and logic analysis
4. **Output Generation**: AI generates expected program output if not provided
5. **Document Creation**: System formats the practical into PDF/Word document
6. **File Storage**: Generated documents are stored and made available for download
7. **Usage Tracking**: System updates user's practical count and enforces plan limits

## External Dependencies

### Core Services
- **Local AI Service**: Custom code validation and output generation (no external API required)
- **Stripe**: Payment processing and subscription management (requires STRIPE_SECRET_KEY)
- **Neon Database**: PostgreSQL hosting (requires DATABASE_URL)

### Third-Party Libraries
- **UI Components**: Extensive use of Radix UI primitives for accessibility
- **File Processing**: Multer for file uploads with size and type restrictions
- **Date Handling**: date-fns for date manipulation and formatting
- **Code Highlighting**: Likely used for syntax highlighting in code editor

### Development Tools
- **Replit Integration**: Specialized plugins for Replit environment
- **Build Tools**: esbuild for server bundling, Vite for client bundling
- **Type Safety**: TypeScript with strict configuration across client/server/shared

## Deployment Strategy

### Production Build
- **Client**: Vite builds React app to `dist/public`
- **Server**: esbuild bundles Express server to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Development**: `npm run dev` starts both client and server in development mode
- **Production**: `npm run build && npm start` for production deployment
- **Database**: Separate migration files in `migrations/` directory

### File Structure
- **Shared Types**: Common TypeScript definitions in `shared/` directory
- **Client Code**: React application in `client/` directory
- **Server Code**: Express API and services in `server/` directory
- **Database**: Schema definitions and migrations managed by Drizzle

The application is architected for scalability with clear separation of concerns, type safety throughout, and modern development practices. The use of AI for code validation and document generation provides significant value to students while maintaining a professional, institutional-grade output format.