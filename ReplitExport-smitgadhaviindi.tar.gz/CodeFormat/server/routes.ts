import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertPracticalSchema } from "@shared/schema";
import { validateCode, generateCodeOutput } from "./services/localAI";
import { generatePDFContent, generateWordContent } from "./services/documentGenerator";
import { parsePDFDocument, parseWordDocument, extractPracticalsFromText, type ParsedPractical } from "./services/documentParser";
import multer from "multer";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-06-30.basil",
});

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req: any, file: any, cb: any) => {
    const allowedTypes = ['application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only DOC, DOCX, and TXT files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes
  app.post("/api/register", async (req, res) => {
    try {
      const validatedData = insertPracticalSchema.safeParse(req.body);
      if (!validatedData.success) {
        return res.status(400).json({ message: "Invalid input data" });
      }

      const existingUser = await storage.getUserByEmail(req.body.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(req.body);
      res.json({ user: { id: user.id, username: user.username, email: user.email, plan: user.plan } });
    } catch (error: any) {
      res.status(500).json({ message: "Registration failed: " + error.message });
    }
  });

  // Practical routes
  app.post("/api/practicals", async (req, res) => {
    try {
      const validatedData = insertPracticalSchema.safeParse(req.body);
      if (!validatedData.success) {
        return res.status(400).json({ message: "Invalid practical data" });
      }

      // For demo purposes, using a mock user ID
      // In production, this would come from authentication
      const userId = req.body.userId || "demo-user";
      
      const practical = await storage.createPractical({
        ...validatedData.data,
        userId,
      });

      res.json({ practical });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to create practical: " + error.message });
    }
  });

  app.get("/api/practicals/:id", async (req, res) => {
    try {
      const practical = await storage.getPractical(req.params.id);
      if (!practical) {
        return res.status(404).json({ message: "Practical not found" });
      }
      res.json({ practical });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch practical: " + error.message });
    }
  });

  // Code validation endpoint
  app.post("/api/validate-code", async (req, res) => {
    try {
      const { code, language, aim } = req.body;
      
      if (!code || !language || !aim) {
        return res.status(400).json({ message: "Code, language, and aim are required" });
      }

      const validation = await validateCode(code, language);
      const generatedOutput = await generateCodeOutput(code, language);

      res.json({ 
        validation,
        output: generatedOutput,
        executionTime: "Instant",
        errors: validation.issues 
      });
    } catch (error: any) {
      console.error('Validation error:', error);
      res.status(500).json({ message: "Validation failed: " + error.message });
    }
  });

  // Document generation endpoint
  app.post("/api/generate-document", async (req, res) => {
    try {
      const { practicalId, format } = req.body;
      
      const practical = await storage.getPractical(practicalId);
      if (!practical) {
        return res.status(404).json({ message: "Practical not found" });
      }

      // Mock user for demo
      const user = await storage.getUser(practical.userId) || {
        id: "demo-user",
        username: "Demo Student",
        email: "demo@example.com",
        password: "",
        stripeCustomerId: null,
        stripeSubscriptionId: null,
        plan: "free",
        practicalCount: 0,
        createdAt: new Date(),
      };

      let documentContent: string;
      let mimeType: string;
      let filename: string;

      if (format === "pdf") {
        documentContent = generatePDFContent(practical, user);
        mimeType = "text/html"; // Would be application/pdf in production
        filename = `${practical.title}.html`; // Would be .pdf in production
      } else if (format === "docx") {
        documentContent = generateWordContent(practical, user);
        mimeType = "application/json"; // Would be application/vnd.openxmlformats-officedocument.wordprocessingml.document in production
        filename = `${practical.title}.json`; // Would be .docx in production
      } else {
        return res.status(400).json({ message: "Invalid format. Use 'pdf' or 'docx'" });
      }

      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(documentContent);

    } catch (error: any) {
      res.status(500).json({ message: "Document generation failed: " + error.message });
    }
  });

  // Enhanced file upload endpoint with better parsing
  app.post("/api/upload-practical", upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      let extractedPracticals: ParsedPractical[] = [];

      // Parse based on file type
      if (req.file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        extractedPracticals = await parseWordDocument(req.file.buffer);
      } else if (req.file.mimetype === 'text/plain') {
        // For text files, convert to string and parse with enhanced parser
        const fileContent = req.file.buffer.toString('utf-8');
        // Use the enhanced parser for text files
        extractedPracticals = extractPracticalsFromText(fileContent);
      } else {
        return res.status(400).json({ message: "Unsupported file type" });
      }

      if (extractedPracticals.length === 0) {
        return res.status(400).json({ 
          message: "Could not extract practical details from the uploaded file. Please ensure your document contains recognizable content like code, aims, or programming text. Supported formats: Word documents (.docx) and text files (.txt)" 
        });
      }

      res.json({ 
        message: "File uploaded and parsed successfully",
        practicals: extractedPracticals,
        count: extractedPracticals.length
      });
    } catch (error: any) {
      res.status(500).json({ message: "File upload failed: " + error.message });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "inr", // Using INR for Indian students
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Subscription endpoint
  app.post('/api/create-subscription', async (req, res) => {
    try {
      const { email, username, plan } = req.body;
      
      if (!email || !username || !plan) {
        return res.status(400).json({ message: "Email, username, and plan are required" });
      }

      const customer = await stripe.customers.create({
        email,
        name: username,
      });

      // Price IDs would need to be configured in Stripe dashboard
      let priceId: string;
      switch (plan) {
        case "student":
          priceId = process.env.STRIPE_STUDENT_PRICE_ID || "price_student";
          break;
        case "pro":
          priceId = process.env.STRIPE_PRO_PRICE_ID || "price_pro";
          break;
        default:
          return res.status(400).json({ message: "Invalid plan" });
      }

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      res.status(400).json({ message: "Subscription creation failed: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
