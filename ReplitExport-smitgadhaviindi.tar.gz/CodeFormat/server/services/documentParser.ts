import * as mammoth from 'mammoth';

export interface ParsedPractical {
  practicalNo?: string;
  title: string;
  aim: string;
  code: string;
  language: string;
  output?: string;
}

export async function parsePDFDocument(buffer: Buffer): Promise<ParsedPractical[]> {
  // For now, return a placeholder since pdf-parse has initialization issues
  // In production, you would use a more robust PDF parsing solution
  throw new Error('PDF parsing temporarily unavailable. Please use Word documents or text files.');
}

export async function parseWordDocument(buffer: Buffer): Promise<ParsedPractical[]> {
  try {
    const result = await mammoth.extractRawText({ buffer });
    const text = result.value;
    
    return extractPracticalsFromText(text);
  } catch (error) {
    throw new Error(`Word document parsing failed: ${(error as Error).message}`);
  }
}

export function extractPracticalsFromText(text: string): ParsedPractical[] {
  const practicals: ParsedPractical[] = [];
  
  // Split text into sections that might contain practicals
  const sections = text.split(/(?:practical|program|assignment|exercise)\s*(?:no\.?|#)?\s*(\d+)/i);
  
  for (let i = 1; i < sections.length; i += 2) {
    const practicalNo = sections[i];
    const content = sections[i + 1] || '';
    
    const practical = extractPracticalDetails(content, practicalNo);
    if (practical) {
      practicals.push(practical);
    }
  }
  
  // If no structured practicals found, try to extract a single practical
  if (practicals.length === 0) {
    const singlePractical = extractPracticalDetails(text);
    if (singlePractical) {
      practicals.push(singlePractical);
    }
  }

  // If still no practicals found, create a basic one from the text content
  if (practicals.length === 0 && text.trim().length > 20) {
    const basicPractical = createBasicPractical(text);
    if (basicPractical) {
      practicals.push(basicPractical);
    }
  }
  
  return practicals;
}

function extractPracticalDetails(text: string, practicalNo?: string): ParsedPractical | null {
  // Extract title - be more flexible with patterns
  const titleMatch = text.match(/(?:title|name|topic):\s*(.+?)(?:\n|$)/i) ||
                    text.match(/^(.+?)(?:\n|aim|objective)/i) ||
                    text.match(/(?:program|practical)\s*(?:to\s+)?(.+?)(?:\n|$)/i);
  
  // Extract aim/objective - more flexible patterns
  const aimMatch = text.match(/(?:aim|objective|purpose|goal):\s*(.+?)(?:\n\n|code|program|solution|$)/i) ||
                   text.match(/(?:to\s+)?(?:write|create|implement|develop|program)\s+(.+?)(?:\n\n|code|program|$)/i) ||
                   text.match(/(?:task|requirement):\s*(.+?)(?:\n\n|code|program|$)/i);
  
  // Extract code - look for code blocks or programming patterns
  const codeMatch = extractCodeFromText(text);
  
  // Extract output
  const outputMatch = text.match(/(?:output|result|execution):\s*(.+?)(?:\n\n|$)/i);
  
  // Determine programming language
  const language = detectProgrammingLanguage(codeMatch?.code || text);
  
  // Be more lenient - if we have any content, try to create a practical
  if (!codeMatch?.code && !aimMatch && text.trim().length < 20) {
    return null; // Not enough content
  }
  
  return {
    practicalNo,
    title: titleMatch?.[1]?.trim() || `Practical ${practicalNo || 'Upload'}`.trim(),
    aim: aimMatch?.[1]?.trim() || extractFirstSentence(text) || 'No aim specified',
    code: codeMatch?.code || extractPossibleCode(text) || '',
    language,
    output: outputMatch?.[1]?.trim()
  };
}

function createBasicPractical(text: string): ParsedPractical | null {
  if (text.trim().length < 20) return null;
  
  const language = detectProgrammingLanguage(text);
  const possibleCode = extractPossibleCode(text);
  
  return {
    title: "Uploaded Practical",
    aim: extractFirstSentence(text) || "Practical from uploaded file",
    code: possibleCode || text.trim(),
    language,
    output: undefined
  };
}

function extractFirstSentence(text: string): string {
  const sentences = text.trim().split(/[.!?]+/);
  return sentences[0]?.trim().substring(0, 100) || '';
}

function extractPossibleCode(text: string): string {
  // Look for anything that resembles code
  const lines = text.split('\n');
  const codeLines = lines.filter(line => 
    line.includes('{') || line.includes('}') || 
    line.includes('def ') || line.includes('function') ||
    line.includes('class ') || line.includes('import ') ||
    line.includes('include') || line.includes('print') ||
    line.includes('console.log') || line.includes('System.out')
  );
  
  if (codeLines.length > 0) {
    return codeLines.join('\n');
  }
  
  return '';
}

function extractCodeFromText(text: string): { code: string } | null {
  // Look for code blocks in various formats
  const codePatterns = [
    /```[\w]*\n([\s\S]+?)\n```/g,           // Markdown code blocks
    /(?:code|program|solution):\s*\n([\s\S]+?)(?:\n\n|output|result|$)/i,
    /(?:source\s+code|implementation):\s*\n([\s\S]+?)(?:\n\n|output|result|$)/i,
    // Look for programming language keywords and extract surrounding context
    /((?:def\s+\w+|class\s+\w+|function\s+\w+|#include|public\s+class|<!DOCTYPE|<html)[\s\S]*?)(?:\n\n|output|result|$)/im
  ];
  
  for (const pattern of codePatterns) {
    const match = text.match(pattern);
    if (match) {
      let code = match[1] || match[0];
      // Clean up the code
      code = code.trim().replace(/^\s*\n|\n\s*$/g, '');
      if (code.length > 10) { // Minimum code length
        return { code };
      }
    }
  }
  
  // If no structured code found, look for lines that look like code
  const lines = text.split('\n');
  const codeLines = [];
  let inCodeBlock = false;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.match(/^(def|class|function|if|for|while|#include|public|private|int|void|string|import|from|<\w+|<!DOCTYPE)/)) {
      inCodeBlock = true;
    }
    
    if (inCodeBlock) {
      codeLines.push(line);
      // Stop collecting if we hit a clear delimiter
      if (trimmed.match(/^(output|result|execution|conclusion):/i)) {
        break;
      }
    }
  }
  
  if (codeLines.length > 2) {
    return { code: codeLines.join('\n').trim() };
  }
  
  return null;
}

function detectProgrammingLanguage(text: string): string {
  const languagePatterns = {
    'python': [/def\s+\w+/, /import\s+\w+/, /print\s*\(/, /if\s+__name__\s*==\s*['""]__main__['""]/, /^\s*#/, /:\s*$/m],
    'java': [/public\s+class/, /public\s+static\s+void\s+main/, /System\.out\.print/, /\/\*[\s\S]*?\*\//, /\/\/.*$/m],
    'cpp': [/#include\s*</, /std::/, /cout\s*<</, /int\s+main\s*\(/, /\/\/.*$/m, /\/\*[\s\S]*?\*\//],
    'c': [/#include\s*</, /printf\s*\(/, /int\s+main\s*\(/, /scanf\s*\(/, /\/\*[\s\S]*?\*\//],
    'javascript': [/function\s+\w+/, /const\s+\w+\s*=/, /console\.log/, /\/\/.*$/m, /var\s+\w+/, /let\s+\w+/],
    'html': [/<html/i, /<head/i, /<body/i, /<div/i, /<p/i, /<h[1-6]/i, /<!DOCTYPE/i],
    'css': [/\w+\s*\{/, /[\w-]+\s*:\s*[\w-]+;/, /@media/, /\.[\w-]+/, /#[\w-]+/],
    'php': [/<\?php/, /\$\w+/, /echo\s+/, /function\s+\w+/, /\/\/.*$/m],
    'sql': [/SELECT\s+/i, /FROM\s+/i, /WHERE\s+/i, /INSERT\s+INTO/i, /UPDATE\s+/i, /DELETE\s+FROM/i]
  };
  
  for (const [lang, patterns] of Object.entries(languagePatterns)) {
    for (const pattern of patterns) {
      if (pattern.test(text)) {
        return lang;
      }
    }
  }
  
  return 'text'; // Default fallback
}