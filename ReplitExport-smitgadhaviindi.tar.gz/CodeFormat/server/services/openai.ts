import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error('Missing required OpenAI API key: OPENAI_API_KEY');
}

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface CodeValidationResult {
  isValid: boolean;
  syntaxErrors: string[];
  logicIssues: string[];
  suggestions: string[];
  score: number; // 1-100
}

export interface CodeOutputResult {
  output: string;
  executionTime: string;
  errors: string[];
}

export async function validateCode(code: string, language: string, aim: string): Promise<CodeValidationResult> {
  try {
    const prompt = `You are an expert code reviewer for CS practical assignments. Analyze the following ${language} code and provide validation results in JSON format.

Code:
\`\`\`${language}
${code}
\`\`\`

Practical Aim: ${aim}

Please analyze for:
1. Syntax correctness
2. Logic implementation quality
3. Best practices adherence
4. Alignment with the practical aim
5. Potential improvements

Respond with JSON in this exact format:
{
  "isValid": boolean,
  "syntaxErrors": ["error1", "error2"],
  "logicIssues": ["issue1", "issue2"],
  "suggestions": ["suggestion1", "suggestion2"],
  "score": number (1-100)
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert code reviewer. Always respond with valid JSON in the specified format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      isValid: result.isValid || false,
      syntaxErrors: result.syntaxErrors || [],
      logicIssues: result.logicIssues || [],
      suggestions: result.suggestions || [],
      score: Math.max(0, Math.min(100, result.score || 0)),
    };
  } catch (error) {
    console.error('OpenAI validation error:', error);
    throw new Error("Failed to validate code: " + (error as Error).message);
  }
}

export async function generateCodeOutput(code: string, language: string, aim: string): Promise<CodeOutputResult> {
  try {
    const prompt = `You are a code execution simulator. Given the following ${language} code, predict its output when executed.

Code:
\`\`\`${language}
${code}
\`\`\`

Practical Aim: ${aim}

Provide the expected output, execution details, and any potential runtime errors. Respond with JSON in this exact format:
{
  "output": "expected console output",
  "executionTime": "estimated execution time",
  "errors": ["any runtime errors"]
}

If the code has inputs, assume reasonable test values. Be realistic about the output.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a code execution simulator. Always respond with valid JSON in the specified format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      output: result.output || "No output generated",
      executionTime: result.executionTime || "< 1ms",
      errors: result.errors || [],
    };
  } catch (error) {
    console.error('OpenAI output generation error:', error);
    throw new Error("Failed to generate output: " + (error as Error).message);
  }
}
