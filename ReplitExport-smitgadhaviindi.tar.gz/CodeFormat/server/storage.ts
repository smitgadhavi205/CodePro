import { type User, type InsertUser, type Practical, type InsertPractical } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User>;
  updateUserPlan(userId: string, plan: string): Promise<User>;
  incrementPracticalCount(userId: string): Promise<User>;
  
  // Practical methods
  createPractical(practical: InsertPractical & { userId: string }): Promise<Practical>;
  getPractical(id: string): Promise<Practical | undefined>;
  getPracticalsByUser(userId: string): Promise<Practical[]>;
  updatePractical(id: string, updates: Partial<Practical>): Promise<Practical>;
  deletePractical(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private practicals: Map<string, Practical>;

  constructor() {
    this.users = new Map();
    this.practicals = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      plan: "free",
      practicalCount: 0,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { 
      ...user, 
      stripeCustomerId: customerId, 
      stripeSubscriptionId: subscriptionId 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserPlan(userId: string, plan: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, plan };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async incrementPracticalCount(userId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, practicalCount: (user.practicalCount || 0) + 1 };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async createPractical(practicalData: InsertPractical & { userId: string }): Promise<Practical> {
    const id = randomUUID();
    const practical: Practical = {
      ...practicalData,
      id,
      output: null,
      validationResult: null,
      status: "processing",
      documentUrl: null,
      createdAt: new Date(),
    };
    this.practicals.set(id, practical);
    return practical;
  }

  async getPractical(id: string): Promise<Practical | undefined> {
    return this.practicals.get(id);
  }

  async getPracticalsByUser(userId: string): Promise<Practical[]> {
    return Array.from(this.practicals.values()).filter(
      (practical) => practical.userId === userId,
    );
  }

  async updatePractical(id: string, updates: Partial<Practical>): Promise<Practical> {
    const practical = this.practicals.get(id);
    if (!practical) throw new Error("Practical not found");
    
    const updatedPractical = { ...practical, ...updates };
    this.practicals.set(id, updatedPractical);
    return updatedPractical;
  }

  async deletePractical(id: string): Promise<boolean> {
    return this.practicals.delete(id);
  }
}

export const storage = new MemStorage();
