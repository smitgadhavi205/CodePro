import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  plan: text("plan").default("free"), // free, student, pro
  practicalCount: integer("practical_count").default(0),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const practicals = pgTable("practicals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  aim: text("aim").notNull(),
  language: text("language").notNull(),
  code: text("code").notNull(),
  output: text("output"),
  validationResult: jsonb("validation_result"), // AI validation results
  format: text("format").notNull(), // pdf, docx
  status: text("status").default("processing"), // processing, completed, failed
  documentUrl: text("document_url"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
});

export const insertPracticalSchema = createInsertSchema(practicals).pick({
  title: true,
  aim: true,
  language: true,
  code: true,
  format: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertPractical = z.infer<typeof insertPracticalSchema>;
export type Practical = typeof practicals.$inferSelect;
